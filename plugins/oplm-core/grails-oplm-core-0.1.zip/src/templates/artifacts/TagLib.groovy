@artifact.package@class @artifact.name@ {

}
